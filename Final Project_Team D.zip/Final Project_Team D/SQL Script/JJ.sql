-- Create a schema and name the schema as JJ

CREATE SCHEMA JJ;
USE JJ;

-- Create tables in JJ
/* Create tables based on the data dictionary in JJ project
*/

-- Create Account Table
CREATE TABLE tb_Account(
User_ID VARCHAR(50) PRIMARY KEY,
Password VARCHAR(50) NOT NULL,
User_Type VARCHAR(1) NOT NULL,
CONSTRAINT CHK_User_Type Check (User_Type in ('C' , 'E'))
);

SELECT * FROM tb_Account;

-- Create Customer Table

-- DROP TABLE tb_Customer;

CREATE TABLE tb_Customer(
Customer_ID INT AUTO_INCREMENT PRIMARY KEY,
CUser_ID VARCHAR(50) NOT NULL UNIQUE,
First_Name VARCHAR(50) NOT NULL,
Last_Name VARCHAR(50) NOT NULL,
Phone_Number VARCHAR(20) NOT NULL,
Address VARCHAR(200) NOT NULL,
EMail VARCHAR(50) NOT NULL,
Account_Status NUMERIC(1,0) NOT NULL,
Join_Date DATE NOT NULL DEFAULT '2000-01-01',
FOREIGN KEY (CUser_ID) REFERENCES tb_Account(User_ID),
CONSTRAINT CHK_Account_Status Check (Account_Status in (1, 0))
);

SELECT * FROM tb_Customer;

-- Create Employee Table
-- DROP TABLE tb_Employee;
CREATE TABLE tb_Employee(
Employee_ID INT AUTO_INCREMENT PRIMARY KEY,
EUser_ID VARCHAR(50) NOT NULL UNIQUE,
Manager_ID INT NULL,
First_Name VARCHAR(50) NOT NULL,
Last_Name VARCHAR(50) NOT NULL,
EMail VARCHAR(50) NOT NULL,
Hire_Date DATE NOT NULL DEFAULT '2000-01-01',
FOREIGN KEY (EUser_ID) REFERENCES tb_Account(User_ID),
FOREIGN KEY(Manager_ID) REFERENCES tb_Employee(Employee_ID)
);



SELECT * FROM tb_Employee;

-- Create Customer Order Table
-- DROP TABLE tb_CustomerOrder;
CREATE TABLE tb_CustomerOrder(
Order_ID INT AUTO_INCREMENT PRIMARY KEY,
Customer_ID INT NOT NULL,
Order_Date DATE NOT NULL DEFAULT '2000-01-01',
Order_Quantity INT NOT NULL,
Order_Status VARCHAR(20) NOT NULL,
Pickup_Time TIME NOT NULL,
FOREIGN KEY (Customer_ID) REFERENCES tb_Customer(Customer_ID)
);

SELECT * FROM tb_CustomerOrder;

-- Create Payment Table
-- DROP TABLE tb_Payment;
CREATE TABLE tb_Payment(
Payment_ID INT AUTO_INCREMENT PRIMARY KEY,
Customer_ID INT NOT NULL,
Order_ID INT NOT NULL,
Payment_Date DATE NOT NULL DEFAULT '2000-01-01',
Payment_Method VARCHAR(30) NOT NULL,
Taxes DECIMAL(10,2) NOT NULL,
Total_Bill DECIMAL(10,2) NOT NULL,
Amount_Due DECIMAL(10,2) NOT NULL,
Amount_Paid DECIMAL(10,2) NOT NULL,
FOREIGN KEY (Customer_ID) REFERENCES tb_Customer(Customer_ID),
FOREIGN KEY(Order_ID) REFERENCES tb_CustomerOrder(Order_ID)
);

SELECT * FROM tb_Payment;

-- Create Item Table
-- DROP TABLE tb_Item;
CREATE TABLE tb_Item(
Item_ID INT AUTO_INCREMENT PRIMARY KEY,
Item_Name VARCHAR(30) NOT NULL UNIQUE,
Item_Type VARCHAR(20) NOT NULL,
Price DECIMAL(10,2) NOT NULL,
Calories DOUBLE NOT NULL,
Fats DECIMAL(10,2) NOT NULL,
Is_Sugar_Free NUMERIC(1,0) NOT NULL,
CONSTRAINT CHK_Is_Sugar_Free Check (Is_Sugar_Free in (1, 0))
);

SELECT * FROM tb_Item;

-- Create Order Detail Table
-- DROP TABLE tb_OrderDetail;
CREATE TABLE tb_OrderDetail(
Order_ID INT,
Item_ID INT,
Total_Items INT NOT NULL,
CONSTRAINT PK_OrderDetail PRIMARY KEY (Order_ID,Item_ID),
FOREIGN KEY(Order_ID) REFERENCES tb_CustomerOrder(Order_ID),
FOREIGN KEY(Item_ID) REFERENCES tb_Item(Item_ID)
);

SELECT * FROM tb_OrderDetail;

-- Create Ingredient Table
-- DROP TABLE tb_Ingredient;
CREATE TABLE tb_Ingredient(
Ingredient_ID INT AUTO_INCREMENT PRIMARY KEY,
Item_ID INT NOT NULL,
Ingredient_Name VARCHAR(30) NOT NULL,
Quantity_Available INT NOT NULL,
Measurement VARCHAR(20) NOT NULL,
Expiry_Date DATE NOT NULL DEFAULT '2000-01-01',
Total_Cost DECIMAL(10,2) NOT NULL,
FOREIGN KEY(Item_ID) REFERENCES tb_Item(Item_ID)
);

SELECT * FROM tb_Ingredient;

-- Create Vendor Table

CREATE TABLE tb_Vendor(
Vendor_ID INT AUTO_INCREMENT PRIMARY KEY,
Vendor_Name VARCHAR(100) NOT NULL,
Address VARCHAR(200) NOT NULL,
Contact_Person VARCHAR(50) NOT NULL,
Phone_Number VARCHAR(15) NOT NULL,
EMail VARCHAR(50) NOT NULL,
Website VARCHAR(100) NOT NULL,
Payment_Due DOUBLE NOT NULL
);

SELECT * FROM tb_Vendor;

-- Create Vendor Order Table
-- DROP TABLE tb_VendorOrder;
CREATE TABLE tb_VendorOrder(
Purchase_Order_ID INT AUTO_INCREMENT PRIMARY KEY,
Vendor_ID INT NOT NULL,
Purchase_Order_Date DATE NOT NULL DEFAULT '2000-01-01',
Expected_Date DATE NOT NULL DEFAULT '2000-01-01',
Quantity INT NOT NULL,
Cost DOUBLE NOT NULL,
FOREIGN KEY(Vendor_ID) REFERENCES tb_Vendor(Vendor_ID)
);

SELECT * FROM Tb_VendorOrder;

-- Create Vendor Delivery Table
-- DROP TABLE tb_VendorDelivery;
CREATE TABLE tb_VendorDelivery(
Ingredient_ID INT,
Purchase_Order_ID INT,
Delivery_Status NUMERIC(1,0) NOT NULL,
CONSTRAINT PK_VendorDelivery PRIMARY KEY (Ingredient_ID,Purchase_Order_ID),
CONSTRAINT CHK_Delivery_Status Check (Delivery_Status in (1, 0)),
FOREIGN KEY(Ingredient_ID) REFERENCES tb_Ingredient(Ingredient_ID),
FOREIGN KEY(Purchase_Order_ID) REFERENCES tb_VendorOrder(Purchase_Order_ID)
);

SELECT * FROM tb_VendorDelivery;

/* Insert data on tb_Account*/

/* INSERT INTO tb_Account
VALUES
('Denver09' , 'Abc@123' , 'C'),
('Julia_12' , 'Xyz_009' , 'E'),
('Lee786' , 'Tiger' , 'C'),
('Nagesh12' , 'Nagesh11' , 'E'),
('Krunal04' , 'Abc@123' , 'C'),
('Arun_D' , 'Xyz_009' , 'E'),
('Himalaya_UI' , 'Tiger' , 'C'),
('King_90' , 'Nagesh11' , 'E'),
('Nick1234' , 'Abc@123' , 'C'),
('Galaxy784' , 'Xyz_009' , 'C'),
('Ninja10_A' , 'Tiger' , 'C'),
('Loki5476' , 'Nagesh11' , 'C'),
('Hulk_OP' , 'Tiger' , 'C'),
('Henry.Shell' , 'Qwertyr' , 'C'),
('Kyle_Jane' , 'Qwerty' , 'C'),
('Rohit_BH_12' , 'Qwerty1' , 'C'),
('shigavkp_1994' , 'Qwerty2' , 'C'),
('Joey.PZ' , 'Qwerty3' , 'E'),
('Rachel_S' , 'Qwerty4' , 'E'),
('Tiger_Woods' , 'Qwerty5' , 'E')
; */

SELECT * FROM tb_Account WHERE USER_ID = 'Denver09' AND Password = 'Abc@123' AND User_Type = 'C';
SELECT * FROM tb_Account WHERE USER_ID = 'Rachel_S' AND Password = 'Qwerty4' AND User_Type = 'E';


SELECT COUNT(User_type) FROM tb_Account Where User_Type = 'E';
SELECT COUNT(User_type) FROM tb_Account Where User_Type = 'C';


/* Insert data on tb_Customer*/

/* INSERT INTO tb_Customer (CUser_ID, First_Name, Last_Name, Phone_Number, Address, EMail, Account_Status)
VALUES
('Denver09','Denver','Dubey','7871000123','Cincinnati,OH','Dd@gmail.com',0),
('Lee786','Lee','Chan','+16666777709','222 Avenue, Mason, AZ','xcy@cmail.com',0),
('Krunal04','Krunal','Shigavan','5138281366','Senator 222, OH','shg@yahoo.com',1),
('Himalaya_UI','Himalaya','Batra','1234567890','Houston,TX','hm@gmail.com',1),
('Nick1234','Nick','Jonas','9871008888','San Jose, CA','nc@gmail.com',1),
('Galaxy784','Samsung','Galaxy','4554122100','Delhi Darbar Street, PA','sg@gmail.com',1),
('Ninja10_A','Manny','Smith','1234567891','Dallas,TX','nj@gmail.com',1),
('Loki5476','Darius','Willis','1234567892','Charlotte,NC','gm@gmail.com',1),
('Hulk_OP','Bruce','Banter','1234567892','Houston,TX','okk@gmail.com',1),
('Henry.Shell','Henry','Shell','1234567893','Houston,TX','njit@gmail.com',1),
('Kyle_Jane','Kyle','Jane','1234567894','Calhoun St, OH','ucinn@gmail.com',1),
('Rohit_BH_12','Rohit','Bhoite','1234567895','Metropolis,CA','lock@gmail.com',1),
('shigavkp_1994','Bruce','Wayne','1234567896','Wayne Manor,Gotham','batman@gmail.com',0)
; */


SELECT * FROM tb_Customer;


SELECT COUNT(Customer_ID) FROM tb_Customer;

/* Insert data on tb_Employee*/

/* INSERT INTO tb_Employee (EUser_ID, First_Name, Last_Name, EMail, Hire_Date)
VALUES
('Julia_12','Julia','Rebello','jj@yahoo.com','2022-08-09'),
('Nagesh12','Nagesh','Rao','NG@cmail.com','2022-05-16'),
('Arun_D','Arun','Dubey','ad@yahoo.com','2022-10-19'),
('King_90','Michael','Johnson','mj98@cmail.com','2021-12-03'),
('Joey.PZ','Joey','Tribbiani','JT98@cmail.com','2022-04-04'),
('Rachel_S','Rachel','Green','RG09@cmail.com','2022-05-28'),
('Tiger_Woods','Tiger','Woods','tg12@cmail.com','2022-02-14'); */



SELECT * FROM tb_Employee;


-- UPDATE tb_Employee SET Manager_ID = 7 where Employee_ID in (5, 6) ;
-- DELETE FROM tb_Employee where Employee_ID = 2;

/* Insert data on tb_CustomerOrder*/

/* INSERT INTO tb_CustomerOrder (Customer_ID, Order_Date, Order_Quantity, Order_Status, Pickup_Time)
VALUES
(1, '2022-10-19', 2 , 'Delivered', '11:43:00'),
(1, '2022-10-20', 4 , 'Cancelled', '13:09:00'),
(2, '2022-11-07', 1 , 'Processing', '14:24:00'),
(3, '2022-11-07', 2 , 'Delivered', '12:24:05'),
(4, '2022-11-07', 3 , 'Delivered', '13:29:00'),
(5, '2022-11-07', 2 , 'Delivered', '16:24:34'),
(6, '2022-11-08', 5 , 'Delivered', '10:04:10'),
(7, '2022-11-08', 4 , 'Processing', '11:35:35'),
(8, '2022-11-08', 2 , 'Cancelled', '14:24:00'),
(9, '2022-11-09', 2 , 'Delievered', '12:00:00'),
(10, '2022-11-09', 2 , 'Processing', '12:24:00'),
(12, '2022-11-09', 3 , 'Cancelled', '12:28:00'),
(11, '2022-11-09', 4 , 'Processing', '15:24:00'),
(13, '2022-11-10', 3 , 'Processing', '12:09:10'),
(2, '2022-11-10', 6 , 'Processing', '13:04:00'),
(3, '2022-11-10', 4 , 'Processing', '13:45:50'),
(4, '2022-11-11', 3 , 'Processing', '14:12:00'),
(5, '2022-11-11', 2 , 'Processing', '15:11:00'),
(6, '2022-11-11', 1 , 'Delievered', '15:19:19'),
(10, '2022-11-13', 1 , 'Processing', '16:45:10');

UPDATE tb_CustomerOrder SET Order_Quantity = 1 WHERE Order_ID = 20; */



SELECT * FROM tb_CustomerOrder;

/* Insert data on tb_Payment*/

/* INSERT INTO tb_Payment(Customer_ID, Order_ID, Payment_Date, Payment_Method, Taxes, Total_Bill, Amount_Due, Amount_Paid)
VALUES
(1, 1, '2022-10-19', 'Cash', 6.7, 45.56, 0, 45.56),
(1, 2, '2022-10-20', 'Credit Card', 8.19, 60.76, 14.00, 46.76),
(2, 3, '2022-11-07', 'Cash', 2.5, 20.00, 0, 20.00),
(3, 4, '2022-11-07', 'Cash', 6.7, 45.56, 0, 45.56),
(4, 5, '2022-11-07', 'Credit Card', 8.19, 60.76, 14.00, 46.76),
(5, 6, '2022-11-08', 'Cash', 2.5, 20.00, 0, 20.00),
(6, 7, '2022-11-08', 'Cash', 9.9, 67.78, 0, 67.78),
(7, 8, '2022-11-08', 'Credit Card', 8.19, 60.76, 14.00, 46.76),
(8, 9, '2022-11-08', 'Cash', 2.5, 20.00, 0, 20.00),
(9, 10, '2022-11-09', 'Cash', 6.7, 45.56, 0, 45.56),
(10, 11, '2022-11-09', 'Credit Card', 8.19, 60.76, 14.00, 46.76),
(12, 12, '2022-11-09', 'Cash', 2.5, 20.00, 0, 20.00),
(11, 13, '2022-11-09', 'Cash', 6.7, 45.56, 0, 45.56),
(13, 14, '2022-11-10', 'Credit Card', 8.19, 60.76, 14.00, 46.76),
(2, 15, '2022-11-10', 'Cash', 10.15, 80.89, 0, 80.89),
(3, 16, '2022-11-10', 'Cash', 6.7, 45.56, 0, 45.56),
(4, 17, '2022-11-11', 'Credit Card', 8.19, 60.76, 14.00, 46.76),
(5, 18, '2022-11-11', 'Cash', 2.5, 20.00, 0, 20.00),
(6, 19, '2022-11-11', 'Cash', 6.7, 45.56, 0, 45.56),
(10, 20, '2022-11-13', 'Credit Card', 8.19, 60.76, 14.00, 46.76); */

SELECT * FROM tb_Payment;

/* Insert data on tb_Item*/

/* INSERT INTO tb_Item(Item_Name, Item_Type, Price, Calories, Fats, Is_Sugar_Free)
VALUES
('Orange Juice', 'Juice', 8.5, 20, 9.4, 0),
('Caesar Salad', 'Salad', 5, 15, 4, 1),
('Apple Juice', 'Juice', 8.5, 20, 9.4, 0),
('French Fries', 'Sides', 2, 20, 10, 0),
('Pineapple', 'Juice', 8.5, 20, 9.4, 0),
('Chicken Salad', 'Salad', 7.5, 20, 5, 0),
('Lemon Juice', 'Juice', 8.5, 20, 9.4, 0),
('Garlic Bread', 'Sides', 5, 15, 4, 0),
('Avacado Juice', 'Juice', 8.5, 20, 9.4, 1),
('Carrot Juice', 'Juice', 8.5, 20, 4, 1),
('Cranberry Juice', 'Juice', 8.5, 20, 9.4, 0),
('Grape Juice', 'Juice', 8.5, 20, 4, 0); */

-- UPDATE tb_Item SET Item_Name = 'Pineapple Juice' WHERE Item_ID = 5;

SELECT * FROM tb_Item;

/* Insert data on tb_OrderDetail*/

/* INSERT INTO tb_OrderDetail(Order_ID, Item_ID, Total_Items)
VALUES
(1, 1, 1),
(1, 2, 1),
(2, 1, 2),
(2, 2, 2),
(3, 1, 1),
(4, 6, 1),
(4, 8, 1),
(5, 1, 1),
(5, 2, 1),
(5, 3, 1),
(6, 4, 2),
(7, 7, 5),
(8, 1, 2),
(8, 2, 2),
(9, 12, 2),
(10, 1, 2),
(11, 2, 2),
(12, 12, 2),
(12, 1, 1),
(13, 10, 4),
(14, 11, 3),
(15, 1, 3),
(15, 3, 3),
(16, 11, 4),
(17, 8, 3),
(18, 10, 4),
(19, 11, 1),
(20, 1, 1); */

SELECT * FROM tb_OrderDetail;

/* Insert data on tb_Ingredient*/


/* INSERT INTO tb_Ingredient (Item_ID, Ingredient_Name, Quantity_Available, Measurement, Expiry_Date, Total_Cost)
VALUES
(1, 'Orange', 80, 'lbs', '2022-12-31', 2110.5),
(1, 'Sugar', 100, 'lbs', '2023-06-08', 1090),
(2, 'Vinegar', 50, 'oz', '2022-12-09', 850.55),
(2, 'Cottage Cheese', 86, 'lbs', '2022-12-31', 3110.5),
(2, 'Tomatoe', 100, 'lbs', '2023-06-08', 800.5),
(3, 'Apple', 89, 'lbs', '2023-12-09', 1099.55),
(4, 'Potatoe', 86, 'lbs', '2022-12-31', 3110.5),
(4, 'Salt', 100, 'lbs', '2024-06-08', 1800.5),
(5, 'Pineapple', 89, 'lbs', '2023-12-09', 1099.55),
(6, 'Chicken', 90, 'lbs', '2022-12-31', 1110.5),
(7, 'Lemon', 20, 'lbs', '2023-06-08', 200.5),
(8, 'Bread', 23, 'lbs', '2023-12-09', 599.55),
(9, 'Avacado', 86, 'lbs', '2022-12-31', 3110.5),
(10, 'Carrot', 100, 'lbs', '2023-06-08', 1200.5),
(11, 'Cranberry', 89, 'lbs', '2023-12-09', 1099.55),
(12, 'Grape', 86, 'lbs', '2022-12-31', 1010.5); */



SELECT * FROM tb_Ingredient;

/* Insert data on tb_Vendor*/

/* INSERT INTO tb_Vendor(Vendor_Name, Address, Contact_Person, Phone_Number, EMail, Website, Payment_Due)
VALUES
('Soham Enterprises', 'Mason, OH', 'Soham Pradhan', '898-000-1234','sp@vcv.com', 'www.spent.com', 1230.55 ),
('NY Market', 'NY Hill, NY', 'Jim Willis', '124-089-1234','JW@ny.com', 'www.ny.com', 5402.28 ),
('Clifton Market', 'Hamilton, OH', 'Jeff Besos', '453-000-1234','clmkt@vcv.com', 'www.cliftonmkt.com', 995.15),
('ESPS Enterprises', 'ER Langer, KY', 'Nancy Dewis', '888-230-1239','ND@esps.com', 'www.esps.com', 5402.28),
('Findlay Market', '222 Senator Place, IN', 'John Cena', '453-000-2231','FDMKT@vcv.com', 'www.FDmkt.com', 1995.25); */

SELECT * FROM tb_Vendor;

/* Insert data on tb_VendorOrder*/
/* INSERT INTO tb_VendorOrder(Vendor_ID, Purchase_Order_Date, Expected_Date, Quantity, Cost)
VALUES
(1, '2022-11-29', '2022-12-10', 34, 4568.89),
(2, '2022-11-27', '2022-12-05', 50, 2012.5),
(3, '2022-11-28', '2022-12-10', 90, 6568.89),
(4, '2022-11-28', '2022-12-05', 12, 800.5),
(5, '2022-11-30', '2022-12-10', 109, 2568.89),
(1, '2022-11-30', '2022-12-05', 56, 900.5),
(2, '2022-11-30', '2022-12-05', 12, 1900.5),
(4, '2022-11-30', '2022-12-06', 156, 7800)
;*/

SELECT * FROM tb_VendorOrder;

/* Insert data on tb_VendorDelivery*/

/* INSERT INTO tb_VendorDelivery(Ingredient_ID, Purchase_Order_ID, Delivery_Status)
VALUES
(1, 1, 0),
(2, 2, 1),
(3, 1, 0),
(5, 3, 0),
(7, 3, 0),
(8, 3, 0),
(10, 4, 1),
(9, 4, 1),
(4, 5, 1),
(1, 6, 0),
(3, 6, 0),
(5, 7, 1),
(10, 8, 0),
(8, 8, 0),
(5, 8, 0); */

SELECT * FROM tb_VendorDelivery;

SELECT * FROM tb_Account;
SELECT * FROM tb_Customer;
SELECT * FROM tb_Employee;
SELECT * FROM tb_CustomerOrder;
SELECT * FROM tb_Payment;
SELECT * FROM tb_Item;
SELECT * FROM tb_OrderDetail;
SELECT * FROM tb_Ingredient;
SELECT * FROM tb_Vendor;
SELECT * FROM tb_VendorOrder;
SELECT * FROM tb_VendorDelivery;

/* Sales Report Query */ 

SELECT SUM(Amount_Paid) AS TotalSales
FROM tb_Payment
WHERE Payment_Date BETWEEN '2022-10-01' AND '2022-11-30';

/* Ingredient Report Query */

SELECT Ingredient_Name, Quantity, Purchase_Order_Date, Vendor_Name, Delivery_Status  
FROM tb_Vendor 
JOIN tb_VendorOrder ON tb_Vendor.Vendor_ID=tb_VendorOrder.Vendor_ID
JOIN tb_VendorDelivery ON tb_VendorOrder.Purchase_Order_ID = tb_VendorDelivery.Purchase_Order_ID
JOIN tb_Ingredient ON tb_VendorDelivery.Ingredient_ID= tb_Ingredient.Ingredient_ID
WHERE Purchase_Order_Date BETWEEN  '2022-11-27' AND '2022-11-29';

